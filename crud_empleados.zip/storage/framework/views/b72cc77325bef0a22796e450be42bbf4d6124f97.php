<?php $__env->startSection('content'); ?>
	<div class="row justify-content-center mt-2">
	<div class="col-6">
		<a href="<?php echo e(route('empleados.index')); ?>">Ver listado de empleados</a>
		<hr>
		<div class="card">
			<?php if(is_null($empleado->foto)): ?>
				<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/78/Sin_foto.svg/768px-Sin_foto.svg.png" class="card-img-top" alt="...">
			<?php else: ?>
				<img src="<?php echo e(route('empleados.foto',$empleado->foto)); ?>" class="card-img-top" alt="...">
			<?php endif; ?>
		
		<div class="card-body">
			<h2 class="text-primary">Código: <?php echo e($empleado->codigo); ?>	</h2>
			<h5 class="card-title">DNI: <?php echo e($empleado->dni); ?> <?php echo e($empleado->nombre); ?> <?php echo e($empleado->apellido); ?></h5>
			<p class="card-text"><?php echo e($empleado->departamento); ?> - <?php echo e($empleado->ciudad); ?></p>
			<p>Direccion: <?php echo e($empleado->direccion); ?></p>
			<p>Fecha de nacimiento: <?php echo e($empleado->fecha_nacimiento); ?></p>
		</div>
		<div class="card-header">
			<form method="POST"  id="frmEliminar" action="<?php echo e(route('empleados.destroy',$empleado->id)); ?>">
				<?php echo csrf_field(); ?>
				<?php echo method_field('DELETE'); ?>
			</form>
			<button type="submit" class="btn btn-danger" form="frmEliminar">Eliminar</button>

			<a href="<?php echo e(route('empleados.edit',$empleado->id)); ?>" class="btn btn-warning">Editar</a>
			
			
		</div>
	</div>
	</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crud_empleados\resources\views/empleado/show.blade.php ENDPATH**/ ?>