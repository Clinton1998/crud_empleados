<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Crud Empleados</title>
    </head>
    <body>
        <div class="container">
            <h2>Bienvenido a CRUD de empleados</h2>
        </div>
    </body>
</html>
